<?php $__env->startSection('content'); ?>

    <div class="main-content">
        <div class="wrapper flex">
            <?php $__currentLoopData = $page_blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page_block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page_block->type == '1'): ?>
                    <div class="about_area" id="about">
                        <div class="container">
                            <div class="row">
                                <!--section title-->
                                <div class="col-md-12 col-sm-12 col-lg-12">
                                    <div class="section_title">
                                        <h2 class="title"><span><?php echo $page_block->header; ?></span></h2>
                                    </div>
                                </div>
                                <!--end section title-->
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <?php echo $page_block->text; ?>

                                </div>
                            </div>
                        </div>
                    </div>

                <?php elseif($page_block->type=='2'): ?>
                    <div class="portfolio_area" id="projects">
                        <div class="container">
                            <div class="row">
                                <!--section title-->
                                <div class="col-md-12">
                                    <div class="section_title">
                                        <h2 class="title"><span>Направления компании</span></h2>
                                    </div>
                                </div>
                                <!--end section title-->
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="portfolio_nav">
                                        <ul>
                                            <?php $__currentLoopData = $page_block->directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="filter" data-filter=".<?php echo e($direction->name, false); ?>"><?php echo e($direction->name, false); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </div>
                                </div>
                                <div class="project_maxitup">
                                    <!--single portfolio item-->
                                    <?php $__currentLoopData = $page_block->directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $direction->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-4 col-sm-6 mix <?php echo e($direction->name, false); ?>">
                                                <div class="portfolio  ">
                                                    <div class="single_protfolio">
                                                        <div class="prot_imag">
                                                            <a class="/venobox" href="/uploads/images/<?php echo e($item->image, false); ?>" data-gall="myGallery">
                                                                <img src="/uploads/images/thumbnail/<?php echo e($item->image, false); ?>" alt="" />
                                                            </a>
                                                            <div class="hover_port_text">
                                                                <h2><a href="#"><?php echo e($direction->name, false); ?> <?php echo e($item->title, false); ?></a></h2>
                                                                <p> <?php echo e($item->text, false); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php elseif($page_block->type=='3'): ?>
                    <?php echo $page_block->text; ?>

                <?php elseif($page_block->type=='4'): ?>
                    <section class="page-block-doc" id="block<?php echo e($page_block->id, false); ?>">
                        <div class="container">
                            <h1><?php echo e($page_block->header, false); ?></h1>
                            <?php echo $page_block->text; ?>

                        </div>
                    </section>
                <?php elseif($page_block->type=='5'): ?>
                    <section class="page-block-link" id="block<?php echo e($page_block->id, false); ?>">
                        <div class="container">
                            <h1><?php echo e($page_block->header, false); ?></h1>
                            <?php echo $page_block->text; ?>

                        </div>
                    </section>
                <?php elseif($page_block->type=='6'): ?>
                    <section class="page-block-pdf" id="block<?php echo e($page_block->id, false); ?>">
                        <div class="container">
                            <h1><?php echo e($page_block->header, false); ?></h1>
                            <?php echo $page_block->text; ?>

                        </div>
                    </section>
                <?php elseif($page_block->type=='7'): ?>

                <!-- HOME SLIDER -->
                    <div class="slider-wrap home-1-slider" id="home">
                        <div id="mainSlider" class="nivoSlider slider-image">
                            <?php $__currentLoopData = $page_block->sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $slider->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="/img/slider1.jpg" alt="main slider" title="#htmlcaption<?php echo e($item->id, false); ?>"/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php $__currentLoopData = $page_block->sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $slider->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="htmlcaption<?php echo e($item->id, false); ?>" class="nivo-html-caption slider-caption-<?php echo e($item->id, false); ?>">
                                    <div class="slider-progress"></div>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="slide1-text slide-text">
                                                    <div class="middle-text">
                                                        <div class="left_sidet1">
                                                            <div class="cap-title wow slideInRight" data-wow-duration=".9s" data-wow-delay="0s">
                                                                <h1><?php echo e($item->title, false); ?></h1>
                                                            </div>
                                                            <div class="cap-dec wow slideInRight" data-wow-duration="1.1s" data-wow-delay="0s">
                                                                <h2><?php echo e($item->text, false); ?></h2>
                                                            </div>
                                                            <div class="cap-readmore animated fadeInUpBig" data-wow-duration="1.5s" data-wow-delay=".5s">
                                                                <a href="#contact" >Заказать</a>
                                                                <!--										<a href="#" class="hover_slider_button">Смотреть каталог</a>-->
                                                            </div>
                                                        </div>
                                                        <div class="right_sidet1">
                                                            <div class="slide-image1">
                                                                <img class="wow slideInUp"  data-wow-duration="1.5s" data-wow-delay="0s" src="/uploads/<?php echo e($item->image, false); ?>" alt="slider caption" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                    <!-- HOME SLIDER -->
                <?php elseif($page_block->type=='8'): ?>
                    <div class="all-area" style="background: rgba(0, 0, 0, 0) url('/uploads/<?php echo e($page_block->image, false); ?>') repeat scroll 0 0 / cover">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo $page_block->text; ?>

                                </div>
                            </div>
                        </div>
                    </div>
        </div>
        <?php elseif($page_block->type=='9'): ?>
            <?php $__currentLoopData = $page_block->photosets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section id="photo-gallery">
                    <div class="container" id="block<?php echo e($page_block->id, false); ?>">
                        <h2><?php echo e($photoset->name, false); ?></h2>
                        <div class="wrapper flex">
                            <?php $__currentLoopData = $photoset->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="image-preview">
                                    <div class="photo-gallery-item">
                                        <a href="/uploads/images/<?php echo e($photo->image, false); ?>" class="modalbox">
                                            <img src="/uploads/images/thumbnail/<?php echo e($photo->image, false); ?>" alt="">
                                        </a>

                                        <div class="title">
                                            <?php echo e($photo->name, false); ?>

                                        </div>
                                        <?php if($photo->text!=''): ?>
                                            <div class="title">
                                                <?php echo e($photo->text, false); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif($page_block->type=='10'): ?>
            <?php $__currentLoopData = $page_block->mail_forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section class="mail-form" id="block<?php echo e($page_block->id, false); ?>">
                    <div class="container form-area<?php echo e($item->id, false); ?>">
                        <h2><?php echo e($item->name, false); ?></h2>
                        <?php echo $page_block->text; ?>

                        <form id="sendform<?php echo e($item->id, false); ?>" class="send-form" method="post">
                            <?php echo e(csrf_field(), false); ?>

                            <div class="row">
                                <?php $__currentLoopData = $item->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col4">
                                        <input type="text" class="form-control <?php echo e($field->field_name, false); ?>" rel="<?php echo e($field->field_name, false); ?>"
                                               id="<?php echo e($field->field_name, false); ?><?php echo e($item->id, false); ?>"
                                               name="<?php echo e($field->field_name, false); ?>"
                                               required
                                               placeholder="<?php echo e($field->field_value, false); ?>">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-textarea">
                                    <textarea name="message<?php echo e($item->id, false); ?>" id="message<?php echo e($item->id, false); ?>"
                                              placeholder="Комментарий…"></textarea>
                            </div>
                            <div class="text-center">
                                <button type="button" class="submit-button" rel="<?php echo e($item->id, false); ?>">Отправить</button>
                            </div>
                            <div class="clearfix"></div>
                            <input type="hidden" name="uid" value="<?php echo e($item->id, false); ?>">
                        </form>
                    </div>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fai/PhpstormProjects/himik-avto/resources/views/page.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<!--[if lt IE 7]><html lang="ru" class="lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html lang="ru" class="lt-ie9 lt-ie8"><![endif]-->
<!--[if IE 8]><html lang="ru" class="lt-ie9"><![endif]-->
<!--[if gt IE 8]><!-->
<html lang="ru">
<!--<![endif]-->
<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="description" content="" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/favicon.png" type="image/png"/>
    <link rel="stylesheet" href="css/menu-style.css" />
    <?php echo $__env->make('layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

URL: <?php echo e($data['url'], false); ?><br/>
IP: <?php echo e($data['ip'], false); ?><br/>

<?php if(key_exists('fio', $data)): ?>
    <?php if(isset($data['fio'])): ?>
        ФИО: <?php echo e($data['fio'], false); ?><br/>
    <?php endif; ?>
<?php endif; ?>
<?php if(key_exists('name', $data)): ?>
    <?php if(isset($data['name'])): ?>
        Наименование: <?php echo e($data['name'], false); ?><br/>
    <?php endif; ?>
<?php endif; ?>
E-mail: <?php echo e($data['email'], false); ?><br/>
<?php if(key_exists('phone', $data)): ?>
    <?php if(isset($data['phone'])): ?>
        Телефон: <?php echo e($data['phone'], false); ?><br/>
        <?php endif; ?>
<?php endif; ?>
Текст сообщения: <?php echo e($data['message'], false); ?>



</body>
</html>
<?php /**PATH /home/fai/PhpstormProjects/himik-avto/resources/views/emails/sendform.blade.php ENDPATH**/ ?>
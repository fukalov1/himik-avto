<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--Start nav  area -->
<div class="nav_area" id="sticker">
    <div class="container">
        <div class="row">
            <!--logo area-->
            <div class="col-md-3 col-sm-3 col-xs-4">
                <div class="logo"><a href="/"><img src="/img/logo.png" alt="" /></a></div>
            </div>
            <!--end logo area-->
            <!--nav area-->
            <div class="col-md-7 col-sm-7 col-xs-6">
                <!--  nav menu-->
                <nav class="menu">
                    <ul class="navid">
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page->relation): ?>
                                <li class="menu-item-has-children">
                                    <?php if($page->redirect==''): ?>
                                        <?php if($page->relation): ?>
                                            <span>
                                        <?php echo $page->name; ?>

                                    </span>
                                        <?php else: ?>
                                            <a href='/<?php echo e($page->url, false); ?>'><?php echo $page->name; ?> </a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a href='/<?php echo e($page->redirect, false); ?>'><?php echo $page->name; ?> </a>
                                    <?php endif; ?>
                                    <ul class="sub-menu">
                                        <?php $__currentLoopData = $page->sub_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($sub_page->redirect==''): ?>
                                                <li><a href='/<?php echo e($sub_page->url, false); ?>'><?php echo $sub_page->name; ?> </a></li>
                                            <?php else: ?>
                                                <li><a href='/<?php echo e($sub_page->redirect, false); ?>'><?php echo $sub_page->name; ?> </a></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php else: ?>
                                <li>
                                    <?php if($page->redirect==''): ?>
                                        <a href='/<?php echo e($page->url, false); ?>'><?php echo $page->name; ?> </a>
                                    <?php else: ?>
                                        <a href='<?php echo e($page->redirect, false); ?>'><?php echo $page->name; ?> </a>
                                    <?php endif; ?>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </nav>
                <!--end  nav menu-->
                <!--moblie menu area-->
                <div class="dropdown mabile_menu">
                    <a data-toggle="dropdown" class="mobile-menu" href="#"><span>  </span><i class="fa fa-bars"></i></a>
                    <ul class="dropdown-menu mobile_menus drop_mobile navid">
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page->relation): ?>
                                <li class="menu-item-has-children">
                                    <?php if($page->redirect==''): ?>
                                        <?php if($page->relation): ?>
                                            <span>
                                                <?php echo $page->name; ?>

                                            </span>
                                        <?php else: ?>
                                            <a href='/<?php echo e($page->url, false); ?>'><?php echo $page->name; ?> </a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a href='<?php echo e($page->redirect, false); ?>'><?php echo $page->name; ?> </a>
                                    <?php endif; ?>
                                    <ul class="sub-menu">
                                        <?php $__currentLoopData = $page->sub_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($sub_page->redirect==''): ?>
                                                <li><a href='/<?php echo e($sub_page->url, false); ?>'><?php echo $sub_page->name; ?> </a></li>
                                            <?php else: ?>
                                                <li><a href='/<?php echo e($sub_page->redirect, false); ?>'><?php echo $sub_page->name; ?> </a></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php else: ?>
                                <li>
                                    <?php if($page->redirect==''): ?>
                                        <a href='/<?php echo e($page->url, false); ?>'><?php echo $page->name; ?> </a>
                                    <?php else: ?>
                                        <a href='/<?php echo e($page->redirect, false); ?>'><?php echo $page->name; ?> </a>
                                    <?php endif; ?>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <!--end moblie menu-->
            </div>
            <!--end nav area-->
            <div class="col-md-2 col-sm-2 col-xs-12 text-right header-phone">
               <a href="tel:<?php echo e($phone, false); ?>">
                <?php echo e($phone, false); ?>

               </a>
            </div>
        </div>
    </div>
</div>
<!--end header  area -->
<?php /**PATH /home/fai/PhpstormProjects/himik-avto/resources/views/layouts/header.blade.php ENDPATH**/ ?>
<!-- google font  -->
<link href='https://fonts.googleapis.com/css?family=Oxygen:400,700,300' rel='stylesheet' type='text/css'>
<!-- Favicon
============================================ -->
<link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon">

<!-- Bootstrap CSS
============================================ -->
<link rel="stylesheet" href="/css/bootstrap.min.css">
<!-- Add venobox -->
<link rel="stylesheet" href="/venobox/venobox.css" type="text/css" media="screen" />
<!-- owl.carousel CSS
============================================ -->
<link rel="stylesheet" href="/css/owl.carousel.css">

<!-- owl.theme CSS
============================================ -->
<link rel="stylesheet" href="/css/owl.theme.css">

<!-- owl.transitions CSS
============================================ -->
<link rel="stylesheet" href="/css/owl.transitions.css">

<!-- font-awesome.min CSS
============================================ -->
<link rel="stylesheet" href="/css/font-awesome.min.css">
<!-- Nivo Slider CSS -->
<link rel="stylesheet" href="/css/nivo-slider.css">
<!-- animate CSS
============================================ -->
<link rel="stylesheet" href="/css/animate.css">

<!-- normalize CSS
============================================ -->
<link rel="stylesheet" href="/css/normalize.css">
<!-- main CSS
============================================ -->
<link rel="stylesheet" href="/css/main.css">

<!-- style CSS
============================================ -->
<link rel="stylesheet" href="style.css">

<!-- responsive CSS
============================================ -->
<link rel="stylesheet" href="/css/responsive.css">

<script src="/js/vendor/modernizr-2.8.3.min.js"></script>
